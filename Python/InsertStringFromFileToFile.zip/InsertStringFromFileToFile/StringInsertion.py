#=======================================================================
# Function   : insert substring into long string in a certain interval
#
# Input      : long string to be seperated
#              substring to be inserted
#              interval to be inserted
#
# Output     : file or stdout
#=======================================================================
def insertStr(longstr, substr, interval):
    f = open('Output.txt', 'a')
    strlen = len(longstr)
    num = strlen / interval
    rest = strlen % interval
    loffset = 0
    for x in xrange(1,num):
        f.write(longstr[loffset:(loffset+interval)])
        f.write(substr)
        loffset = loffset + interval
    if rest == 0:
        f.write(longstr[loffset:(loffset+interval)])
    else:
        f.write(longstr[loffset:(loffset+interval)])
        f.write(substr)
        loffset = loffset + interval
        f.write(longstr[loffset:(loffset+rest)])
    f.close()
    return
#=========================================================================
# Function   : insert substring from a file, then output to another file
#
# Input      : 
#             line: how many lines inside the input file
#
# Output     : Output file
#=========================================================================

def fileStrInsert(line):
    Myfile = open("input.txt", "r")
    for x in xrange(1,line+1):
        data = Myfile.readline()
        insertStr(data, ' ', 2)
        
    